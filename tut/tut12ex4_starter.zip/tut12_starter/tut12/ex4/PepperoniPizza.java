package tut12.ex4;

public class PepperoniPizza extends Pizza {
    public PepperoniPizza(String s, Topping cheese, Topping pep, Topping ham) {
        super(s, cheese, pep, ham);
        this.setName("PepperoniPizza");
    }
}

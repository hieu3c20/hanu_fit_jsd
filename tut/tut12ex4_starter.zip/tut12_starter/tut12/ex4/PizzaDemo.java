package tut12.ex4;

import java.util.Arrays;
import java.util.List;

public class PizzaDemo {

    public static List<Pizza> createPizzas() {
        Pizza.Topping t1 = new Pizza.Topping("cheese", 1, 2);
        Pizza.Topping t2 = new Pizza.Topping("pepperoni", 2, 2);
        Pizza.Topping t3 = new Pizza.Topping("ham", 3, 2);
        Pizza.Topping t4 = new Pizza.Topping("cheese", 2, 2);
        Pizza.Topping t5 = new Pizza.Topping("pepperoni", 3, 2);
        Pizza.Topping t6 = new Pizza.Topping("ham", 4, 2);
        // TODO: create and return a list of at least 5 different pizzas
        return null;
    }

    public static void main(String[] args) {
        List<Pizza> pizzas = createPizzas();
        // TODO: perform SQL-like operations required in Exercise 4

    }
}

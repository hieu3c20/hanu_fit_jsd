package tut12.ex4;

public class HamAndCheesePizza extends Pizza {

    public HamAndCheesePizza(String s, Topping cheese, Topping pep, Topping ham) {
        super(s, cheese, pep, ham);
        this.setName("HamAndCheesePizza");
    }
}

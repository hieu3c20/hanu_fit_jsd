package tut12.ex4;

public class TropicalPizza extends Pizza {

    public TropicalPizza(String s, Topping cheese, Topping pep, Topping ham) {
        super(s, cheese, pep, ham);
        this.setName("TropicalPizza");
    }
}

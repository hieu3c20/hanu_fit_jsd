package tut12.ex4;

/**
 * Represents a Pizza.
 */
public abstract class Pizza implements Comparable<Pizza> {
    private String pizzaName;
    private Topping cheeseTopping;
    private Topping pepTopping;
    private Topping hamTopping;
    private String size;

    protected String getName() {
        return pizzaName;
    }

    protected void setName(String pizzaName) {
        this.pizzaName = pizzaName;
    }

    public Pizza(String s, Topping cheese, Topping pep, Topping ham) {
        size = s;
        cheeseTopping = cheese;
        pepTopping = pep;
        hamTopping = ham;
    }

    private double sizeToCost() {
        if (size.equals("small")) {
            return 10.0;
        } else if (size.equals("medium")) {
            return 12.0;
        } else {
            return 14.0;
        }
    }

    public double calcCost() {
        return sizeToCost()
                + (cheeseTopping != null ? cheeseTopping.calcCost() : 0)
                + (pepTopping != null ? pepTopping.calcCost() : 0)
                + (hamTopping != null ? hamTopping.calcCost() : 0);
    }

    protected Topping getCheeseTopping() {
        return cheeseTopping;
    }

    protected Topping getPepTopping() {
        return pepTopping;
    }

    protected Topping getHamTopping() {
        return hamTopping;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    /**
     * @effects return pizza description
     *          e.g. Pizza(small, 1-cheese 2-ham : $16.0)
     */
    protected String getDescription() {
        return this.getName() + "(" + size + ", "
                + ((cheeseTopping != null) ? cheeseTopping.toString() : "")
                + ((pepTopping != null) ? pepTopping.toString() : "")
                + ((hamTopping != null) ? hamTopping.toString() : "")
                + " : $" + calcCost() + ")";
    }

    @Override
    public int compareTo(Pizza o) {
        return Double.compare(this.calcCost(), o.calcCost());
    }

    // static: create objects without Pizza object
    static class Topping {
        private String name;
        private int quantity;
        private double cost;

        public Topping(String name, int quantity, double cost) {
            this.name = name;
            this.quantity = quantity;
            this.cost = cost;
        }

        public double calcCost() {
            return quantity * cost;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }

        public double getCost() {
            return cost;
        }

        @Override
        public String toString() {
            return this.getQuantity() + "@$" + this.getCost()
                    + " - " + this.getName();
        }
    }

}

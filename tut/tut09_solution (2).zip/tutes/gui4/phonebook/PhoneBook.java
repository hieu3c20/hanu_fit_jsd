package tutes.gui4.phonebook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class PhoneBook extends WindowAdapter implements ActionListener {
    private JFrame gui;
    private AddContact addGUI;
    private JTable tblContacts;

    public PhoneBook() {
        createGUI();
    }

    private void createGUI() {
        gui = new JFrame("Phone Book");
        gui.setSize(360, 300);
        gui.addWindowListener(this);

        JMenuBar menu = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(this);
        fileMenu.add(exitMenuItem);
        menu.add(fileMenu);

        gui.setJMenuBar(menu);

        // north panel
        JPanel pnlTop = new JPanel();
        pnlTop.setBackground(Color.YELLOW);
        JLabel lblTitle = new JLabel("Phone Book Application");
        lblTitle.setFont(lblTitle.getFont().deriveFont(Font.BOLD, 15f));
        pnlTop.add(lblTitle);
        gui.add(pnlTop, BorderLayout.NORTH);

        // center panel
        JPanel pnlMiddle = new JPanel();
        pnlMiddle.setLayout(new BorderLayout());
        gui.add(pnlMiddle);

        String[] headers = {"Name", "Phone", ""};
        Object[][] data = {
                {"Vu Minh Tuan", "0982609010", false},
                {"Dang Dinh Quan", "0982496005", false},
        };

        DefaultTableModel tm = new DefaultTableModel(data, headers);
        tblContacts = new JTable(tm) {
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 2) {
                    return Boolean.class;
                } else {
                    return super.getColumnClass(column);
                }
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2;
            }
        };
        tblContacts.getColumnModel().getColumn(0).setPreferredWidth(150);
        tblContacts.getColumnModel().getColumn(1).setPreferredWidth(120);
        JScrollPane scrContacts = new JScrollPane(tblContacts);
        pnlMiddle.add(scrContacts);

        // bottom
        JPanel pnlBottom = new JPanel();
        gui.add(pnlBottom, BorderLayout.SOUTH);

        JButton btnAdd = new JButton("Add");
        btnAdd.addActionListener(this);
        pnlBottom.add(btnAdd);

        JButton btnCheckAll = new JButton("Check All");
        btnCheckAll.addActionListener(this);
        pnlBottom.add(btnCheckAll);

        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(this);
        pnlBottom.add(btnDelete);

        gui.setLocationRelativeTo(null);
    }

    public void display() {
        gui.setVisible(true);
    }

    @Override
    public void windowClosing(WindowEvent e) {
        shutDown();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Add")) {
            if (addGUI == null) addGUI = new AddContact(gui, this);
            addGUI.display();
        } else if (command.equals("Check All")) {
            for (int i = 0; i < tblContacts.getRowCount(); i++) {
                tblContacts.setValueAt(true, i, 2);
            }
        } else if (command.equals("Delete")) {
            int result = JOptionPane.showConfirmDialog(gui, "Are you sure?", "Delete confirmation", JOptionPane.WARNING_MESSAGE);
            if (result == JOptionPane.YES_OPTION) {
                for (int i = tblContacts.getRowCount() - 1; i >= 0; i--) {
                    DefaultTableModel tm = (DefaultTableModel) tblContacts.getModel();
                    boolean delete = (boolean) tm.getValueAt(i, 2);
                    if (delete) {
                        tm.removeRow(i);
                    }
                }
            }
        } else if (command.equals("Exit")) {
            shutDown();
        }
    }

    private void shutDown() {
        System.exit(0);
    }

    public void addContact(String name, String phone) {
        DefaultTableModel model = (DefaultTableModel) tblContacts.getModel();
        model.addRow(new String[]{name, phone});
    }

    public static void main(String[] args) {
        PhoneBook app = new PhoneBook();
        app.display();
    }
}
